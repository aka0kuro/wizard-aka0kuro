import os, shutil, sqlite3, json, glob
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
from xbmc import log
from addonvar import *
from urllib.request import urlopen, Request
from urllib.error import URLError
import xml.etree.ElementTree as ET

def purge_db(db):
	if os.path.exists(db):
		try:
			conn = sqlite3.connect(db)
			cur = conn.cursor()
		except Exception as e:
			log("DB Connection Error: %s" % str(e), xbmc.LOGDEBUG)
			return False
	else: 
		log('%s not found.' % db, xbmc.LOGINFO)
		return False
	cur.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
	for table in cur.fetchall():
		if table[0] == 'version': 
			log('Data from table `%s` skipped.' % table[0], xbmc.LOGDEBUG)
		else:
			try:
				cur.execute("DELETE FROM %s" % table[0])
				conn.commit()
				log('Data from table `%s` cleared.' % table[0], xbmc.LOGDEBUG)
			except Exception as e:
				log("DB Remove Table `%s` Error: %s" % (table[0], str(e)), xbmc.LOGERROR)
	conn.close()
	log('%s DB Purging Complete.' % db, xbmc.LOGINFO)

def clear_packages():
	file_count = len([name for name in os.listdir(packages)])
	for filename in os.listdir(packages):
		file_path = os.path.join(packages, filename)
		try:
			if os.path.isfile(file_path) or os.path.islink(file_path):
				os.unlink(file_path)
			elif os.path.isdir(file_path):
				shutil.rmtree(file_path)
		except Exception as e:
			log('Failed to delete %s. Reason: %s' % (file_path, e), xbmc.LOGINFO)
	xbmc.sleep(1000)
	dialog.ok(addon_name, local_string(30200).format(str(file_count)))
	return

def clear_thumbnails():
	try:
		if os.path.exists(os.path.join(user_path, 'Thumbnails')):
			shutil.rmtree(os.path.join(user_path, 'Thumbnails'))
	except Exception as e:
		log('Failed to delete %s. Reason: %s' % (os.path.join(user_path, 'Thumbnails'), e), xbmc.LOGINFO)
		return
	try:
		if os.path.exists(os.path.join(db_path, 'Textures13.db')):
			os.unlink(os.path.join(db_path, 'Textures13.db'))
	except:
		purge_db(textures_db)
	xbmc.sleep(1000)
	dialog.ok(addon_name, local_string(30201))
	return

def advanced_settings():
	selection = dialog.select(local_string(30202), [local_string(30210), local_string(30211), local_string(30212), local_string(30213), local_string(30214), local_string(30216), local_string(30215)])
	if selection==0:
		xml = os.path.join(advancedsettings_folder, 'less1.xml')
	elif selection==1:
		xml = os.path.join(advancedsettings_folder, '1plus.xml')
	elif selection==2:
		xml = os.path.join(advancedsettings_folder, 'firetv.xml')
	elif selection==3:
		xml = os.path.join(advancedsettings_folder, '2plus.xml')
	elif selection==4:
		xml = os.path.join(advancedsettings_folder,'shield.xml')
	elif selection==5:
		xml = os.path.join(advancedsettings_folder,'rpi4.xml')
	elif selection==6:
		if os.path.exists(advancedsettings_xml):
			os.unlink(advancedsettings_xml)
		xbmc.sleep(1000)
		deleted = dialog.ok(addon_name, local_string(30220))
		os._exit(1)
	else:
		return
	if os.path.exists(advancedsettings_xml):
		os.unlink(advancedsettings_xml)
	shutil.copyfile(xml, advancedsettings_xml)
	xbmc.sleep(1000)
	apply = dialog.ok(addon_name, local_string(30221))
	os._exit(1)

def check_orphaned_dependencies():
	orphaned = []
	orphaned_addons = set()
	addons_folder = os.path.join(home, 'addons')
	
	# Lista de dependencias del sistema que siempre existen
	system_deps = ['xbmc.', 'kodi.', 'script.module.pil', 'script.module.requests', 
	               'script.module.six', 'script.module.simplejson']
	
	dp.create(addon_name, local_string(30230))
	addon_list = [d for d in os.listdir(addons_folder) if os.path.isdir(os.path.join(addons_folder, d))]
	total = len(addon_list)
	
	for idx, addon_folder in enumerate(addon_list):
		dp.update(int((idx / total) * 100), local_string(30230) + '\n' + addon_folder)
		addon_xml = os.path.join(addons_folder, addon_folder, 'addon.xml')
		
		if os.path.exists(addon_xml):
			try:
				tree = ET.parse(addon_xml)
				root = tree.getroot()
				
				for req in root.findall('.//requires/import'):
					dep_addon = req.get('addon')
					
					if not dep_addon:
						continue
					
					# Saltar dependencias del sistema
					is_system = False
					for sys_dep in system_deps:
						if dep_addon.startswith(sys_dep):
							is_system = True
							break
					
					if is_system:
						continue
					
					# Verificar si la dependencia existe
					dep_path = os.path.join(addons_folder, dep_addon)
					if not os.path.exists(dep_path):
						# Verificar si es opcional
						optional = req.get('optional')
						if optional and optional.lower() == 'true':
							continue
						
						# Es una dependencia faltante real
						orphaned.append({'addon': addon_folder, 'missing_dep': dep_addon})
						orphaned_addons.add(addon_folder)
						log('Orphaned dependency found: %s needs %s' % (addon_folder, dep_addon), xbmc.LOGDEBUG)
			except Exception as e:
				log('Error parsing %s: %s' % (addon_folder, str(e)), xbmc.LOGDEBUG)
	
	dp.close()
	
	if orphaned:
		msg = local_string(30230) + ' (%d)\n\n' % len(orphaned)
		for item in orphaned[:10]:
			msg += '- %s\n  ' + local_string(30247) + ': %s\n' % (item['addon'], item['missing_dep'])
		if len(orphaned) > 10:
			msg += '\n' + local_string(30231).format(len(orphaned) - 10)
		
		msg += '\n' + local_string(30233).format(len(orphaned_addons))
		
		if dialog.yesno(addon_name, msg, nolabel=local_string(30044), yeslabel=local_string(30282)):
			deleted = 0
			for addon_id in orphaned_addons:
				try:
					shutil.rmtree(os.path.join(addons_folder, addon_id))
					deleted += 1
					log('Deleted orphaned addon: %s' % addon_id, xbmc.LOGINFO)
				except Exception as e:
					log('Failed to delete %s: %s' % (addon_id, str(e)), xbmc.LOGERROR)
			dialog.ok(addon_name, local_string(30234).format(deleted))
	else:
		dialog.ok(addon_name, local_string(30232))

def check_dead_repos():
	from urllib.parse import urlparse
	dead_repos = []
	addons_folder = os.path.join(home, 'addons')
	
	dp.create(addon_name, local_string(30240))
	repos = [d for d in os.listdir(addons_folder) if d.startswith('repository.') and os.path.isdir(os.path.join(addons_folder, d))]
	
	if not repos:
		dp.close()
		dialog.ok(addon_name, local_string(30246))
		return
	
	total = len(repos)
	
	for idx, repo_folder in enumerate(repos):
		dp.update(int((idx / total) * 100), local_string(30240) + '\n' + repo_folder)
		addon_xml = os.path.join(addons_folder, repo_folder, 'addon.xml')
		
		if not os.path.exists(addon_xml):
			continue
		
		try:
			tree = ET.parse(addon_xml)
			root = tree.getroot()
			
			# Buscar solo la URL de info (addons.xml)
			info_url = None
			for ext in root.findall('.//extension[@point="xbmc.addon.repository"]'):
				for info in ext.findall('info'):
					if info.text and info.text.strip().startswith('http'):
						info_url = info.text.strip()
						break
				if info_url:
					break
			
			# Si no hay URL, es repo local - saltar
			if not info_url:
				continue
			
			# Intentar conectar a la URL
			is_alive = False
			
			# Método 1: Intentar descargar el archivo directamente
			try:
				req = Request(info_url, headers=headers)
				response = urlopen(req, timeout=5)
				if response.getcode() == 200:
					is_alive = True
					log('check_dead_repos: %s OK - %s responds' % (repo_folder, info_url), xbmc.LOGDEBUG)
				response.close()
			except Exception as e1:
				log('check_dead_repos: %s - direct access failed: %s' % (repo_folder, str(e1)), xbmc.LOGDEBUG)
				
				# Método 2: Intentar ping al dominio
				try:
					parsed = urlparse(info_url)
					domain = '%s://%s' % (parsed.scheme, parsed.netloc)
					req = Request(domain, headers=headers)
					response = urlopen(req, timeout=5)
					if response.getcode() in [200, 301, 302, 403, 404]:
						is_alive = True
						log('check_dead_repos: %s OK - domain %s responds' % (repo_folder, domain), xbmc.LOGDEBUG)
					response.close()
				except Exception as e2:
					log('check_dead_repos: %s DEAD - %s' % (repo_folder, str(e2)), xbmc.LOGDEBUG)
			
			# Si no responde, marcar como muerto
			if not is_alive:
				dead_repos.append({'repo': repo_folder, 'url': info_url})
				log('check_dead_repos: %s marked as DEAD' % repo_folder, xbmc.LOGINFO)
		
		except Exception as e:
			log('check_dead_repos: Error with %s: %s' % (repo_folder, str(e)), xbmc.LOGDEBUG)
			continue
	
	dp.close()
	
	if dead_repos:
		msg = local_string(30241) + ' (%d)\n\n' % len(dead_repos)
		for item in dead_repos[:8]:
			msg += '- %s\n' % item['repo']
		if len(dead_repos) > 8:
			msg += '\n' + local_string(30242).format(len(dead_repos) - 8)
		
		if dialog.yesno(addon_name, msg, nolabel=local_string(30044), yeslabel=local_string(30243)):
			deleted = 0
			for item in dead_repos:
				try:
					shutil.rmtree(os.path.join(addons_folder, item['repo']))
					deleted += 1
				except Exception as e:
					log('Failed to delete %s: %s' % (item['repo'], str(e)), xbmc.LOGERROR)
			dialog.ok(addon_name, local_string(30244).format(deleted))
	else:
		dialog.ok(addon_name, local_string(30245))

def clean_addon_database():
	if os.path.exists(addons_db):
		try:
			conn = sqlite3.connect(addons_db)
			cur = conn.cursor()
			cur.execute("SELECT addonID FROM installed")
			installed = [row[0] for row in cur.fetchall()]
			
			orphaned_entries = []
			for addon_id in installed:
				if not os.path.exists(os.path.join(home, 'addons', addon_id)):
					orphaned_entries.append(addon_id)
			
			if orphaned_entries:
				for addon_id in orphaned_entries:
					cur.execute("DELETE FROM installed WHERE addonID=?", (addon_id,))
				conn.commit()
				cur.execute("VACUUM")
				conn.commit()
				conn.close()
				dialog.ok(addon_name, local_string(30250).format(len(orphaned_entries)))
			else:
				conn.close()
				dialog.ok(addon_name, local_string(30251))
		except Exception as e:
			log('Clean addon DB error: %s' % str(e), xbmc.LOGERROR)
			dialog.ok(addon_name, local_string(30252))
	else:
		dialog.ok(addon_name, local_string(30252))

def clear_old_logs():
	log_files = []
	temp_path = os.path.join(home, 'temp')
	
	for pattern in ['kodi.log.*', 'kodi_crashlog*', '*.dmp']:
		log_files.extend(glob.glob(os.path.join(home, pattern)))
		if os.path.exists(temp_path):
			log_files.extend(glob.glob(os.path.join(temp_path, pattern)))
	
	if log_files:
		size = sum(os.path.getsize(f) for f in log_files if os.path.exists(f))
		size_mb = size / (1024 * 1024)
		
		if dialog.yesno(addon_name, local_string(30260).format(len(log_files), size_mb), nolabel=local_string(30044), yeslabel=local_string(30243)):
			for log_file in log_files:
				try:
					os.unlink(log_file)
				except:
					pass
			dialog.ok(addon_name, local_string(30261).format(len(log_files)))
	else:
		dialog.ok(addon_name, local_string(30262))

def clear_epg_cache():
	epg_db = os.path.join(db_path, 'epg.db')
	if os.path.exists(epg_db):
		if dialog.yesno(addon_name, local_string(30270), nolabel=local_string(30044), yeslabel=local_string(30271)):
			try:
				os.unlink(epg_db)
				dialog.ok(addon_name, local_string(30272))
			except Exception as e:
				log('Clear EPG error: %s' % str(e), xbmc.LOGERROR)
				dialog.ok(addon_name, local_string(30273))
	else:
		dialog.ok(addon_name, local_string(30274))

def list_disabled_addons():
	disabled = []
	addons_folder = os.path.join(home, 'addons')
	
	if os.path.exists(addons_db):
		try:
			conn = sqlite3.connect(addons_db)
			cur = conn.cursor()
			cur.execute("SELECT addonID FROM installed WHERE enabled=0")
			disabled_ids = [row[0] for row in cur.fetchall()]
			conn.close()
			
			for addon_id in disabled_ids:
				if os.path.exists(os.path.join(addons_folder, addon_id)):
					disabled.append(addon_id)
		except:
			pass
	
	if disabled:
		msg = local_string(30280).format(len(disabled)) + '\n\n'
		for addon_id in disabled[:15]:
			msg += '- %s\n' % addon_id
		if len(disabled) > 15:
			msg += '\n' + local_string(30281).format(len(disabled) - 15)
		
		if dialog.yesno(addon_name, msg, nolabel=local_string(30044), yeslabel=local_string(30282)):
			for addon_id in disabled:
				try:
					shutil.rmtree(os.path.join(addons_folder, addon_id))
				except:
					pass
			dialog.ok(addon_name, local_string(30283).format(len(disabled)))
	else:
		dialog.ok(addon_name, local_string(30284))

def verify_skin_integrity():
	current_skin = xbmc.getSkinDir()
	skin_path = os.path.join(home, 'addons', current_skin)
	
	if not os.path.exists(skin_path):
		dialog.ok(addon_name, local_string(30290))
		return
	
	required_files = ['addon.xml', '720p/Home.xml', '1080i/Home.xml']
	missing = []
	
	for req_file in required_files:
		if not os.path.exists(os.path.join(skin_path, req_file)):
			missing.append(req_file)
	
	if missing:
		msg = local_string(30291) + '\n\n' + '\n'.join(missing)
		if dialog.yesno(addon_name, msg, nolabel=local_string(30044), yeslabel=local_string(30292)):
			xbmc.executebuiltin('Skin.SetString(SkinHelper.ForcedViews.Disabled,true)')
			xbmc.executebuiltin('Skin.Reset()')
			dialog.ok(addon_name, local_string(30293))
	else:
		dialog.ok(addon_name, local_string(30294))

def clear_temp_subtitles():
	temp_path = os.path.join(home, 'temp')
	if os.path.exists(temp_path):
		subtitle_files = []
		for ext in ['*.srt', '*.sub', '*.ssa', '*.ass']:
			subtitle_files.extend(glob.glob(os.path.join(temp_path, ext)))
		
		if subtitle_files:
			size = sum(os.path.getsize(f) for f in subtitle_files if os.path.exists(f))
			size_mb = size / (1024 * 1024)
			
			if dialog.yesno(addon_name, local_string(30330).format(len(subtitle_files), size_mb), nolabel=local_string(30044), yeslabel=local_string(30243)):
				for sub_file in subtitle_files:
					try:
						os.unlink(sub_file)
					except:
						pass
				dialog.ok(addon_name, local_string(30331).format(len(subtitle_files)))
		else:
			dialog.ok(addon_name, local_string(30332))
	else:
		dialog.ok(addon_name, local_string(30332))

def system_info():
	import platform
	
	kodi_version = xbmc.getInfoLabel('System.BuildVersion')
	
	# Detectar sistema operativo correctamente
	os_name = platform.system()
	os_release = platform.release()
	
	# En Windows, detectar correctamente Windows 11
	if os_name == 'Windows':
		try:
			import sys
			if sys.platform == 'win32':
				# Verificar si es Windows 11
				build_number = platform.version().split('.')[-1]
				if int(build_number) >= 22000:
					os_release = '11'
				elif os_release == '10':
					os_release = '10'
		except:
			pass
	
	os_info = os_name + ' ' + os_release
	
	# Obtener info de RAM y disco usando Kodi InfoLabels
	try:
		# RAM info desde Kodi
		ram_free_str = xbmc.getInfoLabel('System.FreeMemory')
		ram_total_str = xbmc.getInfoLabel('System.TotalMemory')
		
		# Parsear valores (formato: "XXX MB" o "X.XX GB")
		if 'MB' in ram_free_str:
			ram_free = float(ram_free_str.replace('MB', '').strip()) / 1024
		elif 'GB' in ram_free_str:
			ram_free = float(ram_free_str.replace('GB', '').strip())
		else:
			ram_free = 0
		
		if 'MB' in ram_total_str:
			ram_total = float(ram_total_str.replace('MB', '').strip()) / 1024
		elif 'GB' in ram_total_str:
			ram_total = float(ram_total_str.replace('GB', '').strip())
		else:
			ram_total = 0
		
		if ram_total > 0:
			ram_percent = ((ram_total - ram_free) / ram_total) * 100
		else:
			ram_percent = 0
	except:
		ram_free = ram_total = ram_percent = 0
	
	# Disco info usando os.statvfs o shutil
	try:
		if hasattr(os, 'statvfs'):
			stat = os.statvfs(home)
			disk_total = (stat.f_blocks * stat.f_frsize) / (1024**3)
			disk_free = (stat.f_bavail * stat.f_frsize) / (1024**3)
			disk_percent = ((disk_total - disk_free) / disk_total) * 100 if disk_total > 0 else 0
		else:
			import shutil
			usage = shutil.disk_usage(home)
			disk_total = usage.total / (1024**3)
			disk_free = usage.free / (1024**3)
			disk_percent = (usage.used / usage.total) * 100 if usage.total > 0 else 0
	except:
		disk_total = disk_free = disk_percent = 0
	
	# Contar addons y repos
	try:
		addons_folder = os.path.join(home, 'addons')
		addons_count = len([d for d in os.listdir(addons_folder) if os.path.isdir(os.path.join(addons_folder, d))])
		repos_count = len([d for d in os.listdir(addons_folder) if d.startswith('repository.') and os.path.isdir(os.path.join(addons_folder, d))])
	except:
		addons_count = repos_count = 0
	
	# Construir mensaje
	msg = local_string(30340) + '\n\n'
	msg += local_string(30341).format(kodi_version) + '\n'
	msg += local_string(30342).format(os_info) + '\n'
	
	if ram_total > 0:
		msg += local_string(30343).format(ram_free, ram_total, ram_percent) + '\n'
	
	if disk_total > 0:
		msg += local_string(30344).format(disk_free, disk_total, disk_percent) + '\n'
	
	msg += local_string(30345).format(addons_count) + '\n'
	msg += local_string(30346).format(repos_count)
	
	dialog.textviewer(addon_name, msg)