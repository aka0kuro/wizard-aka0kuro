# -*- coding: utf-8 -*-
'''#####-----XBMC Library Modules-----#####'''
import xbmc
import xbmcgui
import xbmcplugin

'''######------External Modules-----#####'''
from inspect import getframeinfo, stack
import sys
import json
import xml.etree.ElementTree as ET
from urllib.parse import quote_plus

'''#####-----Internal Modules-----#####'''
from addonvar import setting_true,addon_name,addon_version,addon_icon,addon_fanart,local_string

def addDir(name,url,mode,iconimage,fanart,description, name2='', version='', addcontext=False,isFolder=True):
	u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&icon="+quote_plus(iconimage) +"&fanart="+quote_plus(fanart)+"&description="+quote_plus(description)+"&name2="+quote_plus(name2)+"&version="+quote_plus(version)
	ok=True
	liz=xbmcgui.ListItem(name)
	liz.setArt({'fanart':fanart,'icon':'DefaultFolder.png','thumb':iconimage})
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description,})
	if addcontext:
		contextMenu = []
		liz.addContextMenuItems(contextMenu)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)

def get_builds(content):
	builds_list = []
	
	# Limpiar caracteres nulos primero
	if isinstance(content, bytes):
		content = content.replace(b'\x00', b'')
	else:
		content = content.replace('\x00', '')
	
	# Intentar decodificar si es bytes
	if isinstance(content, bytes):
		try:
			content = content.decode('utf-8')
		except:
			try:
				content = content.decode('latin-1')
			except:
				xbmc.log('get_builds: Failed to decode content', xbmc.LOGERROR)
				return builds_list
	
	# Limpiar caracteres nulos después de decodificar
	content = content.replace('\x00', '')
	
	# Log para debugging (primeros 500 caracteres)
	try:
		preview = str(content[:500]).replace('\x00', '')
		xbmc.log('get_builds: Content preview: %s' % preview, xbmc.LOGDEBUG)
	except:
		xbmc.log('get_builds: Could not create preview', xbmc.LOGDEBUG)
	
	# Intentar JSON
	try:
		data = json.loads(content)
		if 'builds' in data:
			builds = data['builds']
		elif isinstance(data, list):
			builds = data
		else:
			builds = [data]
		
		for build in builds:
			builds_list.append({
				'name': build.get('name', ''),
				'version': build.get('version', '0'),
				'url': build.get('url', ''),
				'icon': build.get('icon', addon_icon),
				'fanart': build.get('fanart', addon_fanart),
				'description': build.get('description', local_string(30031))
			})
		xbmc.log('get_builds: Successfully parsed JSON, found %d builds' % len(builds_list), xbmc.LOGDEBUG)
	except Exception as e:
		xbmc.log('get_builds: JSON parse failed: %s' % str(e), xbmc.LOGDEBUG)
		# Intentar XML
		try:
			builds = ET.fromstring(content)
			for build in builds.findall('build'):
				item = {}
				try: item['name'] = build.get('name')
				except: item['name'] = ''
				try: item['version'] = build.find('version').text
				except: item['version'] = '0'
				try: item['url'] = build.find('url').text
				except: item['url'] = ''
				try: item['icon'] = build.find('icon').text
				except: item['icon'] = addon_icon
				try: item['fanart'] = build.find('fanart').text
				except: item['fanart'] = addon_fanart
				try: item['description'] = build.find('description').text
				except: item['description'] = local_string(30031)
				builds_list.append(item)
			xbmc.log('get_builds: Successfully parsed XML, found %d builds' % len(builds_list), xbmc.LOGDEBUG)
		except Exception as e2:
			xbmc.log('get_builds: XML parse failed: %s' % str(e2), xbmc.LOGERROR)
			xbmc.log('get_builds: Content type appears to be: %s' % type(content), xbmc.LOGERROR)
	
	return builds_list

def Log(msg,msgtype):
	logit =False
	if msgtype =='debug' and setting_true('logging.debug'):
		logit = True
	elif msgtype == 'action' and setting_true('logging.actions'):
		logit = True
	elif msgtype == 'info' and setting_true('logging.info'):
		logit = True
	else:
		return
	if logit:
		fileinfo = getframeinfo(stack()[1][0])
		xbmc.log('*__{}__{}*{} Python file name = {} Line Number = {}'.format(addon_name,addon_version,msg,fileinfo.filename,fileinfo.lineno), level=xbmc.LOGINFO)
	else:pass