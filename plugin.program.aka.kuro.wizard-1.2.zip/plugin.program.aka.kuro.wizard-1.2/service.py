#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, base64
from urllib.request import urlopen, Request
from addonvar import *
from resources.lib.modules.utils import get_builds

def check_updates():
    if current_build not in [local_string(30320), '']:
        req = Request(buildfile, headers=headers)
        response = urlopen(req).read()
        version = 0.0
        builds = get_builds(response)
        for build in builds:
            if build['name'] == current_build:
                try:
                    version = float(build['version'])
                except:
                    version = 0.0
        if version > current_version:
            msg = (local_string(30120).format(current_build) + '\n' +
                   local_string(30121).format(str(current_version)) + '\n' +
                   local_string(30122).format(str(version)) + '\n' +
                   local_string(30123).format(addon_name))
            dialog.ok(addon_name, msg)

def save_menu():
    save_items = []
    choices = [local_string(30131), local_string(30132), local_string(30133), local_string(30134)]
    save_select = dialog.multiselect(addon_name + "[COLOR lime] - " + local_string(30130) + "[/COLOR]", choices, preselect=[])

    if save_select == None:
        return
    else:
        for index in save_select:
            save_items.append(choices[index])
    if local_string(30131) in save_items:
        setting_set('savefavs', 'true')
    else:
        setting_set('savefavs', 'false')
    if local_string(30132) in save_items:
        setting_set('savesources', 'true')
    else:
        setting_set('savesources', 'false')
    if local_string(30133) in save_items:
        setting_set('savedebrid', 'true')
    else:
        setting_set('savedebrid', 'false')
    if local_string(30134) in save_items:
        setting_set('saveadvanced', 'true')
    else:
        setting_set('saveadvanced', 'false')

    setting_set('firstrunSave', 'true')
    return

if __name__ == '__main__':
    try:
        if isBase64(buildfile):
            buildfile = base64.b64decode(buildfile).decode('utf8')
    except:
        pass

    current_build = setting('buildname')
    try:
        current_version = float(setting('buildversion'))
    except:
        current_version = 0.0

    if not setting('firstrunSave') == 'true':
        save_menu()

    check_updates()

    if setting('firstrun') == 'true':
        from resources.lib.modules import addonsEnable
        addonsEnable.enable_addons()
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.executebuiltin('UpdateAddonRepos')